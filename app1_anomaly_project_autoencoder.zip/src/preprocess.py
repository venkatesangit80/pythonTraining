import pandas as pd

def load_and_clean_data(filepath):
    df = pd.read_csv(filepath, parse_dates=["timestamp"])
    df = df.sort_values("timestamp")
    df = df.dropna()
    return df
