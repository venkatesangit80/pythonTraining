import pandas as pd
from sklearn.cluster import KMeans
import pickle

def learn_time_patterns(df, metric="Throughput", n_clusters=3):
    hourly = df.groupby(df['timestamp'].dt.hour)[metric].mean().reset_index()
    model = KMeans(n_clusters=n_clusters, random_state=42).fit(hourly[[metric]])
    labels = model.predict(hourly[[metric]])
    time_map = dict(zip(hourly['timestamp'], labels))
    return model, time_map

def save_model(model, path):
    with open(path, "wb") as f:
        pickle.dump(model, f)
