import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.callbacks import EarlyStopping
import pickle

def train_autoencoder_model(train_df, metric_columns, epochs=50, batch_size=32):
    pivot_df = train_df[train_df['metric_name'].isin(metric_columns)].pivot(index='timestamp', columns='metric_name', values='metric_value').dropna()
    
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(pivot_df)

    input_dim = X_scaled.shape[1]
    model = Sequential([
        Dense(64, activation='relu', input_shape=(input_dim,)),
        Dense(32, activation='relu'),
        Dense(64, activation='relu'),
        Dense(input_dim, activation='linear')
    ])

    model.compile(optimizer='adam', loss='mse')
    early_stop = EarlyStopping(monitor='loss', patience=5, restore_best_weights=True)
    model.fit(X_scaled, X_scaled, epochs=epochs, batch_size=batch_size, callbacks=[early_stop], verbose=0)

    return model, scaler, pivot_df

def save_model(model, scaler, model_path, scaler_path):
    model.save(model_path)
    with open(scaler_path, "wb") as f:
        pickle.dump(scaler, f)
