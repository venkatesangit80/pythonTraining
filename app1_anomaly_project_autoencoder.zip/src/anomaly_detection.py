import pickle
import numpy as np
import pandas as pd

def load_model(model_path, scaler_path):
    with open(model_path, "rb") as f:
        model = pickle.load(f)
    with open(scaler_path, "rb") as f:
        scaler = pickle.load(f)
    return model, scaler

def detect_anomalies(model, scaler, test_df):
    metric_columns = ['Throughput', 'Response Time (ms)', 'Error Count', 'JVM_CPU_Usage (%)', 'Python_CPU_Usage (%)', 'CLR_CPU_Usage (%)']
    test_df = test_df[test_df['metric_name'].isin(metric_columns)]
    pivot_df = test_df.pivot(index='timestamp', columns='metric_name', values='metric_value').dropna()
    X_scaled = scaler.transform(pivot_df)
    preds = model.predict(X_scaled)
    pivot_df["anomaly"] = (preds == -1).astype(int)
    return pivot_df.reset_index()
